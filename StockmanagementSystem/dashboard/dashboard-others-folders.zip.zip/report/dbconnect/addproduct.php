<?php
include('connection.php');


$productname =$_POST['productname'];
$productid =$_POST['productid'];
$datepurchased =$_POST['datepurchased'];
$pricepurchased =$_POST['pricepurchased'];
$salesprice =$_POST['salesprice'];
$EmployeeNumber =$_POST['EmployeeNumber'];
$status =$_POST['status'];
$pair =$_POST['pair'];

$sql="INSERT INTO PRODUCT(PNAME,PID,PSTATUS,PDATE,PURPRICE,ENUMBER,PAIR,PPRICE)
VALUES
('$productname',
'$productid',
'$status',
'$datepurchased',
'$pricepurchased',
'$EmployeeNumber',
'$pair',
 '$salesprice'
 )";

if ( $conn->query($sql)==true)
{
    //echo("entered");
  //echo file_get_contents("");
}
else
{
//echo file_get_contents("https://www.youtube.com/")
echo ("noo"). "<br>". $conn->error;

}

?>