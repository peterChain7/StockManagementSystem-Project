<!DOCTYPE html>
<head>
<title>report</title>
<link rel="stylesheet" href="css/styles/main.css"> 
<link rel="stylesheet" href="css/fonts/main.css">  
<link rel="stylesheet" href="css/forms/main.css">  
<link rel="stylesheet" href="css/tables/main.css">   
</head>
<body>
<!--the main div that holds all entire divisions, closed at the buttom-->
<div id="main-div">

<!--top div for notification for all errors-->
<div id="top-div">

</div>
<!--top div for notification ends here-->
<!--web contents here,  its content division-->
<div id="contents">
<form id="login"class="removeproductform">
<table class="homestatus"width="90%"><tr><td>
<label for ="productname">date range from</label>
<input type ="date"id="range1"class="textbox">
</td>
<td>
<label for ="productname">to</label>
<input type ="date"id="range2"class="textbox">
</td></tr></table>
<input type="submit"value="search">
</form>
</div>
<!--contents of the web ends here /contents div-->
<!--main div left side heigheted starts here-- -->
<!--small div inside main left div starts here----------------------->
<div id="leftdiv-main">

<!--small div inside main left div starts here------------------------->
<div id="leftsmall-first">

    <ul class="add-product" id="zoom">
        <li><a href="addproduct.php">Add product </a></li>
        <li><a href="removeproduct.php">Remove product</a></li>
        <li><a href="adduser.php"> Add user</a></li>
        <li><a href="removeuser.php"> Remove user</a></li>
        <li><a href="updateuser.php"> update user</a></li>
        </ul>
        
        </div>
<div id="leftsmall-second">
    <ul class="add-product" id="zoom2">
        <li><a href="generalreport.php">report</a></li>
        <li><a href="#">product info</a></li>
        <li><a href="#">future</a></li>
        </ul>
</div>
<!--small div inside main left div ends here------------------------->
<!--main div left side heigheted ends here -->
</div>
<!--footer  this is system logo, logout-->
<div id="footer">
</div>
<!--footer ends-->
<!--div kuu imefungwa-->
</div>
</body>
</html>

<!----------------------------------------------END--------------------------->