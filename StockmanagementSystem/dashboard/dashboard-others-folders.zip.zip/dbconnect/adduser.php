<?php
include('connection.php');
$userid=$_POST['userid'];
$firstname=$_POST['firstname'];
$lastname=$_POST['lastname'];
$username=$_POST['username'];
$resident=$_POST['resident'];
$password=$_POST['password'];
$email=$_POST['email'];
$phonenumber=$_POST['phonenumber'];
$role=$_POST['role'];

$sql = "INSERT INTO user(userid,firstname,lastname,username,password,email,phonenumber,role) values ('$userid','$firstname','$lastname','$username','$password','$email','$phonenumber','$role')";
if ($conn->query($sql) === TRUE) 
{
  echo"<div class='alert'><script type='text/javascript'>alert('record successfully added !!');</script></div>";
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>