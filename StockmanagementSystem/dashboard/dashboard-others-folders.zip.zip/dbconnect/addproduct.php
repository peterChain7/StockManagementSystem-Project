<?php
include('connection.php');
$pname =$_POST['productname'];
$pid =$_POST['productid'];
$pstatus =$_POST['status'];
$purchasingdate =$_POST['datepurchased'];
$userid =$_POST['EmployeeNumber'];
$pprice =$_POST['pricepurchased'];
$salesprice =$_POST['salesprice'];
$pair =$_POST['pair'];
$sql="INSERT INTO PRODUCT(PNAME,PID,PSTATUS,PURCHASING_DATE,USER_ID,PAIR,PPRICE,SALES_PRICE)
VALUES
(
  '$pname',
  '$pid',
  '$pstatus',
  '$purchasingdate',
  '$userid',
  '$pair',
  '$pprice',
   '$salesprice')";
if ( $conn->query($sql)==true)
{
  
}
else
{

}

?>