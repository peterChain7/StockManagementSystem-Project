
<?php
include('connection.php');
$price =$_POST['price'];
$productid =$_POST['productid'];
$userid =$_POST['userid'];
$pair=$_POST['pair'];
$sql = "INSERT INTO `sales` (`salesprice`, `productid`, `userid`, `pair`, `profit`, `userearnings`, `created_at`, `updated_at`, `salesid`) VALUES ('$price', '$productid', '$userid', '$pair', '', '', '', NULL, NULL);";
if ($conn->query($sql) === TRUE) 
{
  echo"<div class='alert'><script type='text/javascript'>alert('record successfully added !!');</script></div>";
  
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

?>