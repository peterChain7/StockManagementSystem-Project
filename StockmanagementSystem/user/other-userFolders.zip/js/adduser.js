    const firstname = document.getElementById('firstname')
    const lastname = document.getElementById('lastname')
    const username = document.getElementById('username')
    const resident = document.getElementById('resident')
    const password = document.getElementById('password')
    const repeatpassword = document.getElementById('repeatpassword')
    const password = document.getElementById('phonenumber')
   const form = document.getElementById('adduser')
    const errorElement = document.getElementById('top-div')
    
    form.addEventListener('submit', (e) => {
      let messages = []
      if (firstname.value === '' || firstname.value == null) {
        messages.push('enter firstname')
      }

      else if (firstname.value >20) {
        messages.push('Name is much longer')
      }

      else  if (lastname.value === '' || lastname.value == null) 
      {
        messages.push('lastname is required')
      }

      else if (lastname.value >20) {
        messages.push('Name is much longer')
      }

      else  if (username.value === '' || username.value == null) 
      {
        messages.push('username is required')
      }

      else if (username.value >1 || username.value <1) {
        messages.push('avoid numbers: choose text type username')
      }

      else  if (resident.value === '' || resident.value == null) 
      {
        messages.push('resident is empty')
      }

      else if (resident.value >20) {
        messages.push('resident is much longer')
      }

      else  if (password.value === '' || password.value == null) 
      {
        messages.push('password is required')
      }

      
      else  if (password.value !==repeatpassword.value) 
      {
        messages.push('passwords do not match')
      }
    
    
      else if (password.value.length >= 20) {
        messages.push('Password must be less than 20 characters')
        
      }

      else if (password.value.length <=3) 
      {
        messages.push('Password must be greater than 6 characters')
        
      }
    
      else if (password.value === 'password' ||password.value=='PASSWORD'||password.value=='nywira'||password.value=='NYWIRA') {
        messages.push('Password cannot be password')
      }

      else  if (phonenumber.value === '' || phonenumber.value == null) 
      {
        messages.push('enter phone number')
      }

      if (messages.length > 0) {
        e.preventDefault()
        errorElement.innerText = messages.join(', ')
      }
    })