<?php
include('connection.php');

$productid =$_POST['productid'];
$salesprice =$_POST['salesprice'];
$userid =$_POST['userid'];

$sql="INSERT INTO sales(sales_price,pid,user_id)
VALUES
(
  '$salesprice',
  '$productid',
  '$userid')";
if ( $conn->query($sql)==true)
{
  echo "yes";
}
else
{
  echo "no";
}

?>