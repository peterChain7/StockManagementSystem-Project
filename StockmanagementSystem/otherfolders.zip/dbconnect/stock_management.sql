-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Sep 29, 2020 at 10:19 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `stock_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `USERNAME` varchar(100) NOT NULL,
  `PASSWORD` text NOT NULL,
  `LASTUPDATE` datetime DEFAULT CURRENT_TIMESTAMP,
  `CREATED DATE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`USERNAME`, `PASSWORD`, `LASTUPDATE`, `CREATED DATE`) VALUES
('admin', '21232f297a57a5a743894a0e4a801fc3', '2020-09-25 10:15:54', '0000-00-00 00:00:00'),
('administrator', 'administrator', '2020-09-25 10:25:51', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `PNAME` varchar(100) NOT NULL,
  `PID` varchar(100) NOT NULL,
  `PSTATUS` varchar(100) NOT NULL,
  `PURCHASING_DATE` date NOT NULL,
  `USER_ID` varchar(100) DEFAULT NULL,
  `PAIR` int(11) NOT NULL,
  `PPRICE` float NOT NULL,
  `CREATED_DATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `UPDATE_DATE` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `SALES_PRICE` decimal(10,0) NOT NULL,
  `PROFIT` decimal(10,0) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`PNAME`, `PID`, `PSTATUS`, `PURCHASING_DATE`, `USER_ID`, `PAIR`, `PPRICE`, `CREATED_DATE`, `UPDATE_DATE`, `SALES_PRICE`, `PROFIT`) VALUES
('tecno', '1', 'used', '2020-09-14', '1', 1000, 2000, '2020-09-24 14:21:28', NULL, '0', '0'),
('tecno', '100', 'used', '2020-09-14', '1', 10000, 1000, '2020-09-24 15:49:23', NULL, '0', '0'),
('tecno', '101', 'used', '2020-09-14', '1', 0, 1000, '2020-09-24 15:53:27', NULL, '10000', '0'),
('tecno', '2', 'used', '2020-09-14', '1', 1000, 2000, '2020-09-24 14:26:35', NULL, '0', '0'),
('tecno', '3', 'used', '2020-09-14', '1', 1000, 2000, '2020-09-24 14:26:39', NULL, '0', '0'),
('tecno', '4', 'used', '2020-09-14', '1', 1000, 2000, '2020-09-24 14:26:44', NULL, '0', '0'),
('tecno', '5', 'new', '2020-09-14', '1', 100000, 2000, '2020-09-24 14:43:43', '2020-09-24 14:44:48', '0', '0'),
('tecno', '6', 'used', '2020-09-14', '1', 10000, 1000, '2020-09-24 15:41:47', NULL, '0', '0'),
('tecno', '7', 'used', '2020-09-14', '1', 10000, 1000, '2020-09-24 15:42:55', NULL, '0', '0'),
('WW', 'ASASA', 'WQWQW', '2020-09-09', '1', 0, 2121210, '2020-09-24 13:36:07', NULL, '1212', '0'),
('WW', 'wwe', 'WQWQW', '2020-09-09', '1', 1212, 2121210, '2020-09-24 13:40:34', NULL, '0', '0');

-- --------------------------------------------------------

--
-- Table structure for table `sales`
--

CREATE TABLE `sales` (
  `SALES_PRICE` float NOT NULL,
  `SALES_ID` int(11) NOT NULL,
  `PID` varchar(100) NOT NULL,
  `SALES_DATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `USER_ID` varchar(100) NOT NULL,
  `PROFIT` float NOT NULL,
  `SALESDATE` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TIME` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sales`
--

INSERT INTO `sales` (`SALES_PRICE`, `SALES_ID`, `PID`, `SALES_DATE`, `USER_ID`, `PROFIT`, `SALESDATE`, `TIME`) VALUES
(20000, 1, '7', '2020-09-25 00:02:13', '111', 0, '2020-09-25 00:02:13', '2020-09-24 21:02:13'),
(20000, 2, '7', '2020-09-25 00:02:17', '111', 0, '2020-09-25 00:02:17', '2020-09-24 21:02:17'),
(20000, 3, '7', '2020-09-25 00:02:20', '111', 0, '2020-09-25 00:02:20', '2020-09-24 21:02:20');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `USER_ID` varchar(100) NOT NULL,
  `FIRSTNAME` varchar(50) NOT NULL,
  `LASTNAME` varchar(100) NOT NULL,
  `USERNAME` varchar(100) NOT NULL,
  `RESIDENT` varchar(100) NOT NULL,
  `PASSWRD` varchar(100) NOT NULL,
  `PHONENUMBER` int(11) NOT NULL,
  `REGISTERED` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `LASTUPDATE` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `ROLE` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`USER_ID`, `FIRSTNAME`, `LASTNAME`, `USERNAME`, `RESIDENT`, `PASSWRD`, `PHONENUMBER`, `REGISTERED`, `LASTUPDATE`, `ROLE`) VALUES
('', '', '', 'SELEMANI', '----', '123456', 0, '2020-09-27 16:29:46', NULL, '----'),
('1', '0', '', '', '', '', 0, '2020-09-24 22:57:00', NULL, ''),
('100', 'MARIA', 'MARIA', 'MARIA', '	Arusha', '123456', 123456, '2020-09-28 08:49:59', NULL, '	USER'),
('111', '0', 'saidi', 'seree', 'dodoma', '222222', 1111109, '2020-09-24 22:57:00', NULL, ''),
('12', 'JUMA', 'ALLY', 'JUMA', '	Arusha (Arusha)', '123456', 323232, '2020-09-27 15:03:46', NULL, '	ADMIN'),
('123', 'MICKDADI', 'MICKDADI', 'MICKDADI', '	Dar es Salaam ', '123456', 343434343, '2020-09-27 19:18:11', NULL, '	MANAGER'),
('14', 'LUSAJO', 'LUSAJO', 'LUSAJO', 'DODOMA', '123456', 23232323, '2020-09-27 15:24:05', NULL, 'ADMIN'),
('20', 'SETHI', 'WILSON', 'WILSON', '	Arusha (Arusha)', '123456', 12132323, '2020-09-27 15:05:46', NULL, '	ADMIN'),
('21', 'OMBENI', 'OMBENI', 'OMBENI', '	Iringa (Iringa)', '123456', 12132323, '2020-09-27 15:25:06', NULL, '	ADMIN'),
('222', '0', 'saidirr', 'sereerrr', 'dodomarr', '123456', 1111109, '2020-09-24 22:57:00', NULL, ''),
('26', 'SHAMIR', 'SHAMIR', 'SHAMIR', '	Geita (Geita)', '123456', 23232323, '2020-09-27 15:28:14', NULL, '	USER'),
('30', 'SAIDI', 'SAIDI', 'SAIDI', 'DODOMA', '123456', 2121221, '2020-09-27 16:33:17', NULL, 'USER'),
('32', 'IRENE', 'FELIX', 'IRENE', '	Mara', '123456', 232322323, '2020-09-27 17:31:21', NULL, '	USER'),
('333', '0', 'SAIDI', 'MWAJUMA', 'DODOMA', '123456', 1111109, '2020-09-24 22:57:29', NULL, ''),
('3332', '0', 'SAIDI', 'MWAJUMA', '	Iringa (Iringa)', '111111', 1111109, '2020-09-24 23:14:31', NULL, ''),
('37', 'SELEMANI', 'SELEMANI', 'SELEMANI', 'DODOMA', '123456', 121212, '2020-09-27 17:55:39', NULL, 'USER'),
('40', 'BOB', 'BOB', 'BOB', 'DODOMA', '123456', 1212232, '2020-09-27 17:37:12', NULL, 'MANAGER'),
('42', 'OMBENI', 'OMBENI', 'OMBENI', 'DODOMA', '123456', 2322223, '2020-09-27 19:15:37', NULL, 'USER'),
('ALOYCE', 'ALOYCE', 'ALOYCE', 'ALOYCE', 'MWANZA', '123456', 32323, '2020-09-27 19:15:37', NULL, 'USER'),
('user1', 'admin1', 'admin1', 'admin1', 'dodoma', 'admin1', 755447744, '2020-09-25 08:16:19', NULL, ''),
('USER2', 'MASHAURI', 'HALFAN', 'BISAGA', 'DODOMA', '123456', 993333, '2020-09-25 15:54:26', NULL, 'ADMIN'),
('USER3', 'SHAMIRI', 'SAIDI', 'SELEMANI', 'DODOMA', '123456', 454545656, '2020-09-25 15:55:25', NULL, 'USER');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`PID`),
  ADD KEY `USER_ID` (`USER_ID`);

--
-- Indexes for table `sales`
--
ALTER TABLE `sales`
  ADD PRIMARY KEY (`SALES_ID`),
  ADD KEY `FK_user_id` (`USER_ID`),
  ADD KEY `PID_FK` (`PID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`USER_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sales`
--
ALTER TABLE `sales`
  MODIFY `SALES_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`USER_ID`) REFERENCES `user` (`USER_ID`);

--
-- Constraints for table `sales`
--
ALTER TABLE `sales`
  ADD CONSTRAINT `PID_FK` FOREIGN KEY (`PID`) REFERENCES `product` (`PID`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
