const name = document.getElementById('name')
    const password = document.getElementById('password')
    const form = document.getElementById('login')
    const errorElement = document.getElementById('error')
    
    form.addEventListener('submit', (e) => {
      let messages = []
      if (name.value === '' || name.value == null) {
        messages.push('Name is required')
      }

      else if (name.value >20) {
        messages.push('Name is much longer')
      }

      else  if (password.value === '' || password.value == null) 
      {
        messages.push('password is required')
      }
    
    
      else if (password.value.length >= 20) {
        messages.push('Password must be less than 20 characters')
        
      }

      else if (password.value.length <=3) 
      {
        messages.push('Password must be greater than 6 characters')
        
      }
    
      else if (password.value === 'password' ||password.value=='PASSWORD'||password.value=='nywira'||password.value=='NYWIRA') {
        messages.push('Password cannot be password')
      }

     

      if (messages.length > 0) {
        e.preventDefault()
        errorElement.innerText = messages.join(', ')
      }
    })